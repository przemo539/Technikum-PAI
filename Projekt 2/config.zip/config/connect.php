<?php 
//$polaczenie = @mysql_connect('mysql.hostinger.pl','u272880767_zadan','123456') or die('Błąd połaczenia z serwerem');
//mysql_select_db('u272880767_zadan',$polaczenie) or die('Błąd wybrania bazy');
$polaczenie = @mysql_connect('localhost','root','') or die('Błąd połaczenia z serwerem');
mysql_select_db('PAI2',$polaczenie) or die('Błąd wybrania bazy');
?>