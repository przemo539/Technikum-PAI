<?php 
include_once('connect.php');
include_once('./function/function.php');
$adres = 'http://localhost/pai2/';
$_SESSION['adres'] = $adres;
?>